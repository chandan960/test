<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "db_blog");
define("KEYWORDS", "Blog site");
define("AUTHOR", "Chandan Saha");
define("TITLE", "This is popular blog site");

?>