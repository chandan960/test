<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>


<?php

if (!isset($_REQUEST['userid']) || $_REQUEST['userid']==null) {
    echo "<script>window.location = 'userlist.php';</script>";
   // header("Location:postlist.php");
}else{
    $id=$_GET['userid'];
}

?>



        <div class="grid_10">
    
            <div class="box round first grid">
                <h2>View User Details</h2>
                 <?php
                if (isset($_REQUEST['submit'])) {
                  echo "<script>window.location = 'userlist.php';</script>";
                }
                ?>
                <div class="block">               
                 <form action="viewuser.php" method="post" >
                    <table class="form">
                    <?php
              $value=$db->getById("tbl_user","*","id='$id'");
             if($value){

                  ?>
                           <tr>
                           
                            <td colspan="2">
                                <input type="hidden" value="<?php echo $value['id'] ;?>" name="id" class="medium" />
                            </td>
                        </tr> 
                         <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['name'] ;?>" name="name" readonly class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>User Name</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['username'] ;?>" name="username" readonly class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" value="<?php echo $value['email'] ;?>" name="email" readonly class="medium" />
                            </td>
                        </tr>
                     
                   
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Details</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="details" readonly>
                                    <?php echo $value['details'] ;?>
                                </textarea>
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                <label>Role</label>
                            </td>
                            <td>
                                <input type="text" value="<?php 
                                if($value['role']==0){
                                  echo "Admin";
                                }
                                elseif($value['role']==1){
                                  echo "Author";
                                }
                                elseif($value['role']==2){
                                  echo "Editor";
                                }
                                else{
                                  echo "No role";
                                }

                                ?>" name="role" readonly class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Ok" />
                            </td>
                        </tr>
                        <?php } ?>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
    <?php include 'inc/footer.php'; ?>