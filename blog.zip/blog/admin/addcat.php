﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if (isset($_REQUEST['submit'])) {
    extract($_REQUEST);
    $name=$fm->validation($_REQUEST['name']);
    if (empty($name)) {
        echo "<span class='error'>Field must not be empty !!</span>";
    }else{
        $catinsert=$db->Insert("tbl_category","name='$name'");
        if ($catinsert==true) {
            echo "<span class='success'>Category inserted Successfully !!</span>";
        }else{
            echo "<span class='error'>Category inserted Failed !!</span>";
        }

    }
}
?>


        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Category</h2>
               <div class="block copyblock"> 
                 <form action="addcat.php" method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" name="name" placeholder="Enter Category Name..." class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
   <?php include 'inc/footer.php'; ?>