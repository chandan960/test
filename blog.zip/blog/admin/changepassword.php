﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <?php
            if (isset($_REQUEST['submit'])) {
                extract($_REQUEST);
                $id=Session::get('id');
                $oldpass=$fm->validation($_REQUEST['oldpass']);
                $newpass=$fm->validation($_REQUEST['newpass']);
                $oldpassword=md5($oldpass);
                $password=md5($newpass);
                if($oldpassword==""){
                    echo "<span class='error'>Old Password is not empty.</span>";
                }
                elseif($password==""){
                    echo "<span class='error'>New Password is not empty.</span>";
                }
                else{
                $value=$db->getById("tbl_user","*","id='$id'");
                if($value==true){
                    if($oldpassword==$value['password']){
                        $value=$db->Update("tbl_user","password='$password'","id='$id'");
                        if($value==true){
                            //echo "<span class='success'>New password Update..</span>";
                            //Session::destroy();
                            session_destroy();
                        }else{
                            echo "<span class='error'>Password not update.</span>";
                        }

                    }else{
                  echo "<span class='error'>Old password not match</span>";
                    }
                 }
                }
            }
            ?>
		
            <div class="box round first grid">
                <h2>Change Password</h2>
                <div class="block">               
                 <form action="changepassword.php" method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Old Password</label>
                            </td>
                            <td>
                                <input type="password" placeholder="Enter Old Password..."  name="oldpass" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>New Password</label>
                            </td>
                            <td>
                                <input type="password" placeholder="Enter New Password..." name="newpass" class="medium" />
                            </td>
                        </tr>
						 
						
						 <tr>
                            <td>
                            </td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
       <?php include 'inc/footer.php'; ?>