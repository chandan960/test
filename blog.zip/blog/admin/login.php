<?php include '../lib/Session.php'; 
Session::checkLogin();
?>
<?php include '../config/config.php'; ?>
<?php include '../lib/Database.php'; ?>
<?php include '../helpers/Format.php'; ?>
<?php
  $db=new Database;
  $fm=new Format;
?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<?php
	if (isset($_REQUEST['login'])) {
	extract($_REQUEST);
	$username=$fm->validation($_REQUEST['username']);
	$password=$fm->validation(md5($_REQUEST['password']));




	//$username=mysqli_real_escape_string($username);
	//$password=mysqli_real_escape_string($password);
	
	$result= $db->getById("tbl_user","*","username='$username' AND password='$password'");

	if ($result==true) {
		Session::set("login",true);
		Session::set("id",$result['id']);
		Session::set("name",$result['name']);
		Session::set("username",$result['username']);
		Session::set("email",$result['email']);
		Session::set("details",$result['details']);
		Session::set("role",$result['role']);
		header("Location:index.php");
				
	}else{
		echo "<span style='color:red;font-size:18px;'>Username or Password not matched...</span>";
		
	}
	
}
	?>
	<section id="content">
		<form action="login.php" method="post">
			<h1>Admin Login</h1>
			<div>
				<input type="text" placeholder="Username" required="" name="username"/>
			</div>
			<div>
				<input type="password" placeholder="Password" required="" name="password"/>
			</div>
			<div>
				<input type="submit" value="Log in" name="login" />
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="forgotpassword.php">Forgot Password</a>
		</div>
		<div class="button">
			<a href="#">Training with live project</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>