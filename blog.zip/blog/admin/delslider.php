<?php include '../lib/Session.php'; 
Session::checkSession();
?>
<?php include '../config/config.php'; ?>
<?php include '../lib/Database.php'; ?>
<?php include '../helpers/Format.php'; ?>
<?php
  $db=new Database;
  $fm=new Format;
?>
<?php
if (!isset($_REQUEST['delsliderid']) || $_REQUEST['delsliderid']==null) {
	 echo "<script>window.location = 'sliderlist.php';</script>";
}else{
	$id=$_REQUEST['delsliderid'];

	$sliderpost=$db->getById("tbl_slider","*","id='$id'");
	if($sliderpost){
		$delimglink=$sliderpost['image'];
		unlink($delimglink);
	}
	$sliderpostdelete = $db->Delete("tbl_slider","id='$id'");
	if($sliderpostdelete){
		echo "<script>alert('Slider Deleted Successfully...');</script>";
		echo "<script>window.location = 'sliderlist.php';</script>";
	}else{
		echo "<script>alert('Slider Not Deleted...');</script>";
		echo "<script>window.location = 'sliderlist.php';</script>";
	}
}
        /*if (isset($_REQUEST['delpostid'])) {
        	$id=$_REQUEST['delpostid'];
        	$postdelete = $db->Delete("tbl_post","id='$id'");
        	if ($postdelete==true) {
    echo "<span class='success'>Category deleted Successfully !!</span>";
}else{
    echo "<span class='error'>Category deleted Failed !!</span>";
}
        }*/
  ?>