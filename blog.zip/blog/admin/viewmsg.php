<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>View Message</h2>
                <?php
                if(!isset($_REQUEST['viewid']) || $_REQUEST['viewid']==null){
                    echo "<script>window.location = 'inbox.php';</script>";

                }else{
                    $id=$_REQUEST['viewid'];
                }
                ?>
              <?php
              if(isset($_REQUEST['submit'])){
                 echo "<script>window.location = 'inbox.php';</script>";

              }
              ?>

                <div class="block">               
                 <form action="viewmsg.php" method="post" >
                    <table class="form">
                         <?php
                $value=$db->getById("tbl_contact","*","id='$id'");
                if($value){
                        ?>
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text"  readonly value="<?php echo $value['firstname']." ".$value['lastname'];?>" name="name" class="medium" />
                            </td>
                        </tr>
                       <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" readonly value="<?php echo $value['email'];?>" name="email" class="medium"/>
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Date</label>
                            </td>
                            <td>
                                <input type="text" readonly value="<?php echo $fm->validation($value['date']);?>"  name="date" class="medium" />
                            </td>
                        </tr>
                       
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Message</label>
                            </td>
                            <td>
                                <textarea  class="tinymce" name="message" readonly >
                                  <?php echo $value['message'];?>     
                                </textarea>
                            </td>
                        </tr>
                         
                       
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                         <?php
                    }
                ?>
                    </table>
                    </form>
                </div>
                   
            </div>
        </div>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
    <?php include 'inc/footer.php'; ?>