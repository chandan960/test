<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php

if (!isset($_REQUEST['catid']) || $_REQUEST['catid']==null) {
    echo "<script>window.location = 'catlist.php';</script>";
   // header("Location:catlist.php");
}else{
    $id=$_GET['catid'];
}

?>




<?php

if (isset($_REQUEST['submit'])) {
    extract($_REQUEST);
    $name=$fm->validation($_REQUEST['name']);
    //$name=$_REQUEST['name'];
    $id=$_REQUEST['id'];
    if (empty($name)) {
        echo "<span class='error'>Field must not be empty !!</span>";
    }else{
        $catupdate=$db->Update("tbl_category","name='$name'","id='$id'");
        if ($catupdate==true) {
            echo "<span class='success'>Category updated Successfully !!</span>";
        }else{
            echo "<span class='error'>Category updated Failed !!</span>";
        }

    }
}

?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Category</h2>
               <div class="block copyblock"> 
                <?php
        if(isset($id)){
        $value=$db->getById("tbl_category","*","id='$id'");
        if($value){

          ?>

                 <form action="editcat.php" method="post">
                    <table class="form">
                     <tr>
                            <td>
                                <input type="hidden" name="id" value="<?php echo $value['id'] ;?>" class="medium" />
                            </td>
                        </tr>					
                        <tr>
                            <td>
                                <input type="text" name="name" value="<?php echo $value['name'] ;?>" class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } }?>
                </div>
            </div>
        </div>
   <?php include 'inc/footer.php'; ?>