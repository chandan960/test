<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>


<?php

if (!isset($_REQUEST['editpostid']) || $_REQUEST['editpostid']==null) {
    echo "<script>window.location = 'postlist.php';</script>";
   // header("Location:postlist.php");
}else{
    $id=$_GET['editpostid'];
}

?>





        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Post</h2>
                 <?php
                if (isset($_REQUEST['submit'])) {
                   extract($_REQUEST);
                   $id=$_REQUEST['id'];
                   $cat=$_REQUEST['cat'];
                   $title=$_REQUEST['title'];
                   $body=$_REQUEST['body'];
                   $author=$_REQUEST['author'];
                   $tags=$_REQUEST['tags'];
                   $userid=$_REQUEST['userid'];

//image upload start
                    $permited  = array('jpg', 'jpeg', 'png', 'gif');
                    $file_name = $_FILES['image']['name'];
                    $file_size = $_FILES['image']['size'];
                    $file_temp = $_FILES['image']['tmp_name'];

                    $div = explode('.', $file_name);
                    $file_ext = strtolower(end($div));
                    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
                    $uploaded_image = "upload/".$unique_image;
//image upload end  



          if($title=="" || $cat=="" || $body=="" || $author=="" || $tags==""){
            echo "<span class='error'>Field must not be empty !!</span>";

             }



//image validatin start
         else{    
if(!empty($file_name)){
    if ($file_size >1048567) {
     echo "<span class='error'>Image Size should be less then 1MB!
     </span>";
    } elseif (in_array($file_ext, $permited) === false) {
     echo "<span class='error'>You can upload only:-"
     .implode(', ', $permited)."</span>";
    } else{
    move_uploaded_file($file_temp, $uploaded_image);
    $update=$db->Update("tbl_post","cat='$cat',title='$title',body='$body',image='$uploaded_image',author='$author', tags='$tags',userid='$userid'","id='$id'");
    if ($update) {
     echo "<span class='success'>Data Updated Successfully.</span>";
    }else {
     echo "<span class='error'>Data Not Updated !</span>";
    } 
    } 
    }else{
         $update=$db->Update("tbl_post","cat='$cat',title='$title',body='$body',author='$author', tags='$tags',userid='$userid'","id='$id'");
    if ($update) {
     echo "<span class='success'>Data Updated Successfully.</span>";
    }else {
     echo "<span class='error'>Data Not Updated !</span>";
    } 
    } 
}
//image validatin end              


                }
                ?>
                <div class="block">               
                 <form action="editpost.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                      <?php
if(isset($id)){
$value=$db->getById("tbl_post","*","id='$id'");
if($value){

?>
                         <tr>
                           
                            <td colspan="2">
                                <input type="hidden" value="<?php echo $value['id'] ;?>" name="id" class="medium" />
                            </td>
                        </tr> 
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['title'] ;?>" name="title" class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="cat">
                                    <option>Select Category</option>
                                    <?php
                                $category=$db->getAll("tbl_category","*");
                                if ($category) {
                                    foreach($category as $catvalue){
                                        ?>                                      
                              <option 
                              <?php
                              if($value['cat']==$catvalue['id']){ ?>
                              selected="selected"

                              <?php } ?>

                              value="<?php echo $catvalue['id']; ?>"><?php echo $catvalue['name']; ?></option>
                               <?php
                                    }
                                }
                                 ?>
                                    
                                </select>
                            </td>
                        </tr>
                   
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <img src="<?php echo $value['image'] ;?>" height="80px" width="200px"><br>
                                <input type="file" name="image" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="body">
                                    <?php echo $value['body'] ;?>
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['author'] ;?>" name="author" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Tags</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['tags'] ;?>" name="tags" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="hidden" value="<?php echo Session::get('id');?>" name="userid" class="medium"  />
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                        <?php } }?>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
    <?php include 'inc/footer.php'; ?>