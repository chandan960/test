﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Category List</h2>
                 <?php
                if (isset($_REQUEST['delcat'])) {
                	$id=$_REQUEST['delcat'];
                	$catdelete = $db->Delete("tbl_category","id='$id'");
                	if ($catdelete==true) {
            echo "<span class='success'>Category deleted Successfully !!</span>";
        }else{
            echo "<span class='error'>Category deleted Failed !!</span>";
        }
                }
                ?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Category Name</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>

						<?php
						$category=$db->getAll("tbl_category ORDER BY id DESC","*");
						if ($category) {
							$i=0;
							foreach($category as $value){
								$i++;
						
						?>
						<tr class="odd gradeX">
							<td><?php echo $i; ?></td>
							<td><?php echo $value['name']; ?></td>
							<td><a href="editcat.php?catid=<?php echo $value['id']; ?>">Edit</a> || <a onclick="return confirm('Are you sure Delete!!!');" href="?delcat=<?php echo $value['id']; ?>">Delete</a></td>
						</tr>
						<?php
							}
						}else{}
						?>
						

					</tbody>
				</table>
               </div>
            </div>
        </div>

         <script type="text/javascript">

        $(document).ready(function () {
            setupLeftMenu();

            $('.datatable').dataTable();
			setSidebarHeight();


        });
    </script>
        <?php include 'inc/footer.php'; ?>

