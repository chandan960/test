<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

        <div class="grid_10">
            <div class="box round first grid">
                <h2>Slider List</h2>
                
                <div class="block">  
                    <table class="data display datatable" id="example">
                    <thead>
                        <tr>
                            <th>NO.</th>
                            <th>Slider Title</th>
                            <th>Slider Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i=0;
             $post=$db->getAll("tbl_slider","*");
             if($post){
                    foreach($post as $value){ 
                        $i++;

                        ?>
                        <tr class="odd gradeX">
                            <td><?php echo $i; ?></td>
                            <td><a href="editslider.php?editsliderid=<?php echo $value['id']; ?>"><?php echo $value['title'] ;?></a></td>
                            <td><img src="<?php echo $value['image']; ?>" height="50px" width="250px"></td>
                        <td>
                            <?php
                            if(Session::get('role')=='0'){
                            ?>
                         <a href="editslider.php?editsliderid=<?php echo $value['id']; ?>">Edit</a> || <a onclick="return confirm('Are you sure Delete!!!');" href="delslider.php?delsliderid=<?php echo $value['id']; ?>">Delete</a>

                         <?php } ?>

                        </td>
                        </tr>
             
                <?php }}    ?>
                </tbody>
                </table>
    
               </div>
            </div>
        </div>

         <script type="text/javascript">

        $(document).ready(function () {
            setupLeftMenu();

            $('.datatable').dataTable();
            setSidebarHeight();


        });
    </script>
        <?php include 'inc/footer.php'; ?>