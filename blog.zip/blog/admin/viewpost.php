<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>


<?php

if (!isset($_REQUEST['viewpostid']) || $_REQUEST['viewpostid']==null) {
    echo "<script>window.location = 'postlist.php';</script>";
   // header("Location:postlist.php");
}else{
    $id=$_GET['viewpostid'];
}

?>





        <div class="grid_10">
    
            <div class="box round first grid">
                <h2>Update Post</h2>
                 <?php
                if (isset($_REQUEST['submit'])) {
     echo "<script>window.location = 'postlist.php';</script>";
   // header("Location:postlist.php");
                }
                ?>
                <div class="block">               
                 <form action="viewpost.php" method="post" enctype="multipart/form-data">
                    <table class="form">
                      <?php
if(isset($id)){
$value=$db->getById("tbl_post","*","id='$id'");
if($value){

?>
                         <tr>
                           
                            <td colspan="2">
                                <input type="hidden" value="<?php echo $value['id'] ;?>" name="id" class="medium" />
                            </td>
                        </tr> 
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['title'] ;?>" name="title" class="medium" readonly />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="cat">
                                    <option>Select Category</option>
                                    <?php
                                $category=$db->getAll("tbl_category","*");
                                if ($category) {
                                    foreach($category as $catvalue){
                                        ?>                                      
                              <option 
                              <?php
                              if($value['cat']==$catvalue['id']){ ?>
                              selected="selected"

                              <?php } ?>

                              value="<?php echo $catvalue['id']; ?>"><?php echo $catvalue['name']; ?></option>
                               <?php
                                    }
                                }
                                 ?>
                                    
                                </select>
                            </td>
                        </tr>
                   
                        <tr>
                            <td>
                                <label>Image</label>
                            </td>
                            <td>
                                <img src="<?php echo $value['image'] ;?>" height="100px" width="250px"><br>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="body" readonly>
                                    <?php echo $value['body'] ;?>
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['author'] ;?>" name="author" class="medium" readonly />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Tags</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['tags'] ;?>" name="tags" class="medium" readonly />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="hidden" value="<?php echo Session::get('id');?>" name="userid" class="medium" readonly />
                            </td>
                        </tr>
            <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Ok" />
                            </td>
                        </tr>
                        <?php } }?>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
    <?php include 'inc/footer.php'; ?>