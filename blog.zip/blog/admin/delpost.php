<?php include '../lib/Session.php'; 
Session::checkSession();
?>
<?php include '../config/config.php'; ?>
<?php include '../lib/Database.php'; ?>
<?php include '../helpers/Format.php'; ?>
<?php
  $db=new Database;
  $fm=new Format;
?>
<?php
if (!isset($_REQUEST['delpostid']) || $_REQUEST['delpostid']==null) {
	 echo "<script>window.location = 'postlist.php';</script>";
}else{
	$id=$_REQUEST['delpostid'];

	$post=$db->getById("tbl_post","*","id='$id'");
	if($post){
		$delimglink=$post['image'];
		unlink($delimglink);
	}
	$postdelete = $db->Delete("tbl_post","id='$id'");
	if($postdelete){
		echo "<script>alert('Data Deleted Successfully...');</script>";
		echo "<script>window.location = 'postlist.php';</script>";
	}else{
		echo "<script>alert('Data Not Deleted...');</script>";
		echo "<script>window.location = 'postlist.php';</script>";
	}
}
        /*if (isset($_REQUEST['delpostid'])) {
        	$id=$_REQUEST['delpostid'];
        	$postdelete = $db->Delete("tbl_post","id='$id'");
        	if ($postdelete==true) {
    echo "<span class='success'>Category deleted Successfully !!</span>";
}else{
    echo "<span class='error'>Category deleted Failed !!</span>";
}
        }*/
  ?>