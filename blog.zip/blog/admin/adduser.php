<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php
    $srole=Session::get('role');
    if($srole!='0'){
      echo "<script>window.location = 'index.php';</script>";
   // header("Location:catlist.php");
    }
        ?>

<?php
if (isset($_REQUEST['submit'])) {
    extract($_REQUEST);
    $name=$fm->validation($_REQUEST['name']);
    $username=$fm->validation($_REQUEST['username']);
    $password=$fm->validation(md5($_REQUEST['password']));
    $email=$fm->validation($_REQUEST['email']);
    $role=$fm->validation($_REQUEST['role']);
    $details=$fm->validation($_REQUEST['details']);
    
    if ($name=="") {
        echo "<span class='error'>Name field must not be empty !!</span><br>";
    }
    elseif ($username=="") {
        echo "<span class='error'>User name field must not be empty !!</span><br>";
    }elseif ($password=="") {
        echo "<span class='error'>Password field must not be empty !!</span><br>";
    }elseif ($email=="") {
        echo "<span class='error'>Email field must not be empty !!</span><br>";
    }elseif ($role!="0" && $role!="1" && $role!="2") {
        echo "<span class='error'>Role Select must !!</span><br>";
    }
   else{
        $checkusername=$db->getById("tbl_user","*","username='$username' LIMIT 1");
        $checkemail=$db->getById("tbl_user","*","email='$email' LIMIT 1");
         if($checkusername==true){
             echo "<span class='error'>Username already exist !!</span>";
        }
        elseif($checkemail==true){
             echo "<span class='error'>Email address already exist !!</span>";
        }
        else{
            $userinsert=$db->Insert("tbl_user","name='$name',username='$username',password='$password',email='$email',role='$role',details='$details'");
       
        if ($userinsert==true) {
            echo "<span class='success'>User inserted Successfully !!</span>";
        }else{
            echo "<span class='error'>User inserted Failed !!</span>";
        }
        }

    }
}
?>


        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New User</h2>
               <div class="block copyblock"> 
                 <form action="adduser.php" method="post">
                    <table class="form">
                    <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="name" placeholder="Enter Name..." class="medium" />
                            </td>
                        </tr>					
                        <tr>
                            <td>
                                <label>Username</label>
                            </td>
                            <td>
                                <input type="text" name="username" placeholder="Enter User Name..." class="medium" />
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" name="email" placeholder="Enter Email Address..." class="medium" />
                            </td>
                        </tr>
                            <tr>
                            <td>
                                <label>Password</label>
                            </td>
                            <td>
                                <input type="password" name="password" placeholder="Enter Password..." class="medium" />
                            </td>
                        </tr>
                            <tr>
                            <td>
                                <label>User Role</label>
                            </td>
                           <td>
                                <select id="select" name="role">
                                    <option>Select User Role</option>
                                    <option value="0">Admin</option>
                                    <option value="1">Author</option>
                                    <option value="2">Editor</option> 
                                </select>
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Detail</label>
                            </td>
                            <td>
                                
                                 <textarea class="tinymce" name="details" ></textarea>
                            </td>
                        </tr>
						<tr> 
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="create" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
         <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
   <?php include 'inc/footer.php'; ?>