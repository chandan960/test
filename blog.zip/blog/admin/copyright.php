﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php
            if (isset($_REQUEST['submit'])) {
               extract($_REQUEST);
               $id=1;
               $text=$fm->validation($_REQUEST['text']);

      if($text==""){
        echo "<span class='error'>Field must not be empty !!</span>";

         }
         else{    
         $update=$db->Update("tbl_footer","text='$text'","id='$id'");
    if ($update) {
     echo "<span class='success'>Data Updated Successfully.</span>";
    }else {
     echo "<span class='error'>Data Not Updated !</span>";
    } 
    }  
            }
                ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Copyright Text</h2>
                <?php
                $value=$db->getById("tbl_footer","*","id=1");
                if($value){
                ?> 
                <div class="block copyblock"> 
                 <form action="copyright.php" method="post">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" value="<?php echo $value['text'] ?>" name="text" class="large" />
                            </td>
                        </tr>
						
						 <tr> 
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
                 <?php } ?>
            </div>
        </div>
       <?php include 'inc/footer.php'; ?>