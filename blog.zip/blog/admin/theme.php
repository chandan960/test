<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if (isset($_REQUEST['submit'])) {
    extract($_REQUEST);
    $id=1;
    $theme=$_REQUEST['theme'];
    $value=$db->Update("tbl_theme","theme='$theme'","id='$id'");
    if ($value==true) {
        echo "<span class='success'>Theme updated Successfully !!</span>";
        
    }else{
        echo "<span class='error'>Theme not updated !!</span><br>";
    }
}
?>

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Theme Color Change</h2>
               <div class="block copyblock"> 
           


                 <form action="theme.php" method="post">
                    <table class="form">
                        <?php 
                        $id=1;
                     $value=$db->getById("tbl_theme","*","id='$id'");
                     if ($value==true) {
                        ?>
                     <tr>
                            <td>
                               <input type="radio" name="theme" value="default" 
                               <?php
                               if($value['theme']=='default'){
                                echo "checked";
                               }
                               ?>
                               >Default
                            </td>
                        </tr>
                        <tr>
                            <td>
                               <input type="radio" name="theme" value="green"
                               <?php
                               if($value['theme']=='green'){
                                echo "checked";
                               }
                               ?>
                               >Green
                            </td>
                        </tr>
                        <tr>
                            <td>
                               <input type="radio" name="theme" value="red"
                               <?php
                               if($value['theme']=='red'){
                                echo "checked";
                               }
                               ?>
                               >Red
                            </td>
                        </tr>					
                       
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Change" />
                            </td>
                        </tr>
                        <?php  } ?>
                    </table>
                    </form>
                   
                </div>
            </div>
        </div>
   <?php include 'inc/footer.php'; ?>