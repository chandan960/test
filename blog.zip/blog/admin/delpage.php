<?php include '../lib/Session.php'; 
Session::checkSession();
?>
<?php include '../config/config.php'; ?>
<?php include '../lib/Database.php'; ?>
<?php include '../helpers/Format.php'; ?>
<?php
  $db=new Database;
  $fm=new Format;
?>
<?php
if (!isset($_REQUEST['delid']) || $_REQUEST['delid']==null) {
	 echo "<script>window.location = 'index.php';</script>";
}else{
	$id=$_REQUEST['delid'];

	
	$pagedelete = $db->Delete("tbl_page","id='$id'");
	if($pagedelete){
		echo "<script>alert('Page Deleted Successfully...');</script>";
		echo "<script>window.location = 'index.php';</script>";
	}else{
		echo "<script>alert('Page Not Deleted...');</script>";
		echo "<script>window.location = 'index.php';</script>";
	}
}
      
  ?>