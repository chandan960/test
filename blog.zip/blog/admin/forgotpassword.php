<?php 
include 'lib/Session.php'; 
Session::checkLogin();
?>
<?php include 'config/config.php'; ?>
<?php include 'lib/Database.php'; ?>
<?php include 'helpers/Format.php'; ?>
<?php
  $db=new Database;
  $fm=new Format;
?>
<?php
  if (isset($_REQUEST['forgotpassword'])) {
  extract($_REQUEST);
  $email=$fm->validation($_REQUEST['email']);
  $role=$fm->validation($_REQUEST['role']);

  if(empty($email)){
    echo "Email must not be empty";
  }
  elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
    echo "Email is invalid";
  }
  elseif(empty($role)){
    echo "Role must not be empty";
  }
  else{
  
  $result= $db->getById("tbl_registration","*","email='$email' AND role='$role'");

  if ($result==true) {
    $id=$result['id'];
    $name=$result['name'];
    $email=$result['email'];
    $text=substr($email, 0, 3);
    $rand=rand(10000, 99999);
    $newpass="$text$rand";
    $password=md5($newpass);
    $update= $db->Update("tbl_registration","password='$password'","id='$id'");
    $to=$email;
    $from="parkingmasterbd@gmail.com";
    $subject="Your new password...";
    $message="Your name is :".$name." and Your new password is:".$newpass."please visit website to login.";
    $headers="from: $from";
   // $headers .= 'MIME-Version: 1.0'."\r\n";
       // $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
    $sendmail=mail($to, $subject, $message,$headers);
   // $a=1;
   // if($a==1){
    if($sendmail==true){
      echo "<span style='color:green;font-size:18px;'>Please check your email for new password...</span>";
      header("LOCATION:login.php");
    }else{
    echo "<span style='color:red;font-size:18px;'>Email not send...</span>";  
  }     
  }else{
    echo "<span style='color:red;font-size:18px;'>Email address not matched...</span>";
  }
}
  
}
?>
	<section id="content">
		<form action="forgotpassword.php" method="post">
			<h1>Password Recovery</h1>
			<div>
				<input type="text" placeholder="Enter email address" required="" name="email"/>
			</div>
			
			<div>
				<input type="submit" value="Send" name="submit" />
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="login.php">Log In</a>
		</div>
		<div class="button">
			<a href="#">Training with live project</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>