<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php
$srole=Session::get('role');
$sid=Session::get('id');
?>

        <div class="grid_10">
    
            <div class="box round first grid">
                <h2>User Profile</h2>
                 <?php
                if (isset($_REQUEST['submit'])) {
                    extract($_REQUEST);
                   $id=$_REQUEST['id'];
                   $name=$_REQUEST['name'];
                   //$username=$_REQUEST['username'];
                   $email=$_REQUEST['email'];
                   $details=$_REQUEST['details'];
                   //$role=$_REQUEST['role'];

                   $name=$fm->validation($_REQUEST['name']);
                   //$username=$fm->validation($_REQUEST['username']);
                   $email=$fm->validation($_REQUEST['email']);
                   $details=$fm->validation($_REQUEST['details']);
                  // $role=$fm->validation($_REQUEST['role']);




    if ($name=="") {
        echo "<span class='error'>Name field must not be empty !!</span><br>";
    }
    //elseif ($username=="") {
       // echo "<span class='error'>User name field must not be empty !!</span><br>";
    //}
    elseif ($email=="") {
        echo "<span class='error'>Email field must not be empty !!</span><br>";
    }elseif ($details=="") {
        echo "<span class='error'>Details field must not be empty !!</span><br>";
    }//elseif ($role!="0" && $role!="1" && $role!="2") {
       // echo "<span class='error'>Role Select must !!</span><br>";
    //}
     else{
    $userupdate=$db->Update("tbl_user","name='$name',email='$email',details='$details'","id='$id' AND role='$srole'");
        if ($userupdate==true) {
            echo "<span class='success'>Profile updated Successfully !!</span>";
        }else{
            echo "<span class='error'>Profile updated Failed !!</span>";
        }
   }
       
                             //  echo "<script>window.location = 'userlist.php';</script>";
                }
                ?>
                <div class="block">               
                 <form action="profile.php" method="post" >
                    <table class="form">
                    <?php
              $value=$db->getById("tbl_user","*","id='$sid'");
             if($value){

                  ?>
                           <tr>
                           
                            <td colspan="2">
                                <input type="hidden" value="<?php echo $value['id'] ;?>" name="id" class="medium" />
                            </td>
                        </tr> 
                         <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['name'] ;?>" name="name" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>User Name</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $value['username'] ;?>" name="username" class="medium" readonly/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" value="<?php echo $value['email'] ;?>" name="email" class="medium" readonly />
                            </td>
                        </tr>
                     
                   
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Details</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="details" >
                                    <?php echo $value['details'] ;?>
                                </textarea>
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                <label>Role</label>
                            </td>
                            <td>
                                <input type="text" value="<?php 
                                if($value['role']==0){
                                  echo "Admin";
                                }
                                elseif($value['role']==1){
                                  echo "Author";
                                }
                                elseif($value['role']==2){
                                  echo "Editor";
                                }
                                else{
                                 echo "No role";
                                }

                                ?>" name="role" class="medium" readonly />
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                        <?php } ?>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
    <?php include 'inc/footer.php'; ?>