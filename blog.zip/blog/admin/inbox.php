﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
        	<?php
        	if (isset($_REQUEST['seenid'])) {
        		extract($_REQUEST);
        		$id=$_REQUEST['seenid'];
        		$value=$db->Update("tbl_contact","status='1'","id='$id'");
        		if($value){
        			echo "<span class='success'>Seen the message</span>";
        		}else{
        			echo "<span class='error'>Message not seen</span>";
        		}
        	}
        	?>
        	<?php
        	if (isset($_REQUEST['unseenid'])) {
        		extract($_REQUEST);
        		$id=$_REQUEST['unseenid'];
        		$value=$db->Update("tbl_contact","status='0'","id='$id'");
        		if($value){
        			echo "<span class='success'>Unseen the message</span>";
        		}else{
        			echo "<span class='error'>Message not unseen</span>";
        		}
        	}
        	?>
        		<?php
        	if (isset($_REQUEST['draftid'])) {
        		extract($_REQUEST);
        		$id=$_REQUEST['draftid'];
        		$value=$db->Update("tbl_contact","status='2'","id='$id'");
        		if($value){
        			echo "<span class='success'>Draft the message</span>";
        		}else{
        			echo "<span class='error'>Message not draft</span>";
        		}
        	}
        	?>
        	<?php
        	if (isset($_REQUEST['deleteid'])) {
        		extract($_REQUEST);
        		$id=$_REQUEST['deleteid'];
        		$value=$db->Delete("tbl_contact","id='$id'");
        		if($value){
        			echo "<span class='success'>Delete the message</span>";
        		}else{
        			echo "<span class='error'>Message not delete</span>";
        		}
        	}
        	?>
            <div class="box round first grid">
                <h2>Inbox</h2>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$data=$db-> getAllCondition("tbl_contact","*","status='0'");
						if($data){
							$i=0;
							foreach($data as $value){
								$i++;
								?>

						<tr class="odd gradeX">
							<td><?php echo $i; ?></td>
							<td><?php echo $value['firstname']." ".$value['lastname']; ?></td>
							<td><?php echo $value['email']; ?></td>
							<td><?php echo $fm->textShorten($value['message'],50); ?></td>
							<td><?php echo $fm->formatDate($value['date']); ?></td>
							<td><a href="viewmsg.php?viewid=<?php echo $value['id']; ?>">View</a> || <a href="?seenid=<?php echo $value['id']; ?>">Seen</a> || <a href="replymsg.php?replyid=<?php echo $value['id']; ?>">Reply</a> || <a href="?draftid=<?php echo $value['id']; ?>">Draft</a></td>
						</tr>
							<?php
							}
						}

						?>

					</tbody>
				</table>
               </div>
            </div>
            <div class="box round first grid">
                <h2>Seen Message</h2>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$data=$db-> getAllCondition("tbl_contact","*","status='1'");
						if($data){
							$i=0;
							foreach($data as $value){
								$i++;
								?>

						<tr class="odd gradeX">
							<td><?php echo $i; ?></td>
							<td><?php echo $value['firstname']." ".$value['lastname']; ?></td>
							<td><?php echo $value['email']; ?></td>
							<td><?php echo $fm->textShorten($value['message'],50); ?></td>
							<td><?php echo $fm->formatDate($value['date']); ?></td>
							<td><a href="viewmsg.php?viewid=<?php echo $value['id']; ?>">View</a> || <a href="?unseenid=<?php echo $value['id']; ?>">Unseen</a> || <a href="replymsg.php?replyid=<?php echo $value['id']; ?>">Reply</a>  || <a onclick="return confirm('Are you sure Delete!!!');" href="?deleteid=<?php echo $value['id']; ?>">Delete</a> || <a href="?draftid=<?php echo $value['id']; ?>">Draft</a></td>
						</tr>
							<?php
							}
						}

						?>

					</tbody>
				</table>
               </div>
            </div>
            <div class="box round first grid">
                <h2>Draft Message</h2>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						$data=$db-> getAllCondition("tbl_contact","*","status='2'");
						if($data){
							$i=0;
							foreach($data as $value){
								$i++;
								?>

						<tr class="odd gradeX">
							<td><?php echo $i; ?></td>
							<td><?php echo $value['firstname']." ".$value['lastname']; ?></td>
							<td><?php echo $value['email']; ?></td>
							<td><?php echo $fm->textShorten($value['message'],50); ?></td>
							<td><?php echo $fm->formatDate($value['date']); ?></td>
							<td><a href="viewmsg.php?viewid=<?php echo $value['id']; ?>">View</a> || <a href="?seenid=<?php echo $value['id']; ?>">Seen</a> ||<a href="?unseenid=<?php echo $value['id']; ?>">Unseen</a> || <a href="replymsg.php?replyid=<?php echo $value['id']; ?>">Reply</a>  || <a onclick="return confirm('Are you sure Delete!!!');" href="?deleteid=<?php echo $value['id']; ?>">Delete</a></td>
						</tr>
							<?php
							}
						}

						?>

					</tbody>
				</table>
               </div>
            </div>
        </div>
        
         <script type="text/javascript">

        $(document).ready(function () {
            setupLeftMenu();

            $('.datatable').dataTable();
			setSidebarHeight();


        });
    </script>
        <?php include 'inc/footer.php'; ?>