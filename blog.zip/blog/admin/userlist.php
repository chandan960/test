<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>User List</h2>
                 <?php
                if (isset($_REQUEST['deluser'])) {
                	$id=$_REQUEST['deluser'];
                	$userdelete = $db->Delete("tbl_user","id='$id'");
                	if ($userdelete==true) {
            echo "<span class='success'>User deleted Successfully !!</span>";
        }else{
            echo "<span class='error'>User deleted Failed !!</span>";
        }
                }
                ?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>User Name</th>
							<th>Email</th>
							<th>Details</th>
							<th>Role</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>

						<?php
						$user=$db->getAll("tbl_user","*");
						if ($user) {
							$i=0;
							foreach($user as $value){
								$i++;
						
						?>
						<tr class="odd gradeX">
							<td><?php echo $i; ?></td>
							<td><?php echo $value['name']; ?></td>
							<td><?php echo $value['username']; ?></td>
							<td><?php echo $value['email']; ?></td>
							<td><?php echo $fm->textShorten($value['details'],50); ?></td>
							<td><?php 
							    if($value['role']==0){
							    	echo "Admin";
							    }
								elseif($value['role']==1){
									echo "Author";
								}
								elseif($value['role']==2){
									echo "Editor";
								}
								else{
									echo "No role";
								}

							 ?></td>
							<td><a href="viewuser.php?userid=<?php echo $value['id']; ?>">View</a>
								<?php
                       $srole=Session::get('role');
                       if($srole=='0'){
                        ?>
							 || <a onclick="return confirm('Are you sure Delete!!!');" href="?deluser=<?php echo $value['id']; ?>">Delete</a>

							 <?php } ?>
							 
							</td>
						</tr>
						<?php
							}
						}else{}
						?>
						

					</tbody>
				</table>
               </div>
            </div>
        </div>

         <script type="text/javascript">

        $(document).ready(function () {
            setupLeftMenu();

            $('.datatable').dataTable();
			setSidebarHeight();


        });
    </script>
        <?php include 'inc/footer.php'; ?>

